import { IChainable, INextable, State, StateMachineFragment } from 'aws-cdk-lib/aws-stepfunctions';
import { Construct } from 'constructs';
export interface CustomResourceFlowProps {
    /**
     * The workflow to execute on Create.
     *
     * @default - the onUpdate workflow
     */
    readonly onCreate?: IChainable;
    /**
     * The workflow to execute on Update.
     *
     * @default - no-op
     */
    readonly onUpdate?: IChainable;
    /**
     * The workflow to execute on Delete.
     *
     * @default - no-op
     */
    readonly onDelete?: IChainable;
}
export declare class CustomResourceFlow extends StateMachineFragment {
    readonly startState: State;
    readonly endStates: INextable[];
    constructor(scope: Construct, id: string, props: CustomResourceFlowProps);
}
