import * as cdk from 'aws-cdk-lib';
import { IStateMachine } from 'aws-cdk-lib/aws-stepfunctions';
import { Construct } from 'constructs';
export interface LambdalessWaitConditionProps {
    readonly stateMachine: IStateMachine;
    /**
     * @default Duration.hours(12)
     */
    readonly timeout?: cdk.Duration;
    /**
     * @default - automatically determined by getAttString calls
     */
    readonly count?: number;
    readonly properties?: {
        [key: string]: any;
    };
    readonly resourceType?: string;
    readonly removalPolicy?: cdk.RemovalPolicy;
}
export declare class LambdalessWaitCondition extends Construct {
    readonly attrData: string;
    private readonly uniqueIds;
    private readonly explicitCount?;
    constructor(scope: Construct, id: string, props: LambdalessWaitConditionProps);
    getAttString(uniqueId: string): string;
}
