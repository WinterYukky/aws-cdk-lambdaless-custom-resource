import { IChainable, INextable, IStateMachine, State, StateMachineFragment } from 'aws-cdk-lib/aws-stepfunctions';
import { Construct } from 'constructs';
export interface CustomResourceFlowProps {
    readonly onCreate: IChainable;
    readonly onUpdate?: IChainable;
    readonly onDelete?: IChainable;
}
export declare class CustomResourceFlow extends StateMachineFragment {
    readonly startState: State;
    readonly endStates: INextable[];
    constructor(scope: Construct, id: string, props: CustomResourceFlowProps);
}
export interface OriginalStepFunctionsFlowProps {
    readonly stateMachine: IStateMachine;
}
export declare class OriginalStepFunctionsFlow extends StateMachineFragment {
    readonly startState: State;
    readonly endStates: INextable[];
    constructor(scope: Construct, id: string, props: OriginalStepFunctionsFlowProps);
}
