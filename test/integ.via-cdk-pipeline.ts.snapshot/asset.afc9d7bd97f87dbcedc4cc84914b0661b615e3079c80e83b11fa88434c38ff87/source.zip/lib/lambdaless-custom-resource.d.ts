import * as cdk from 'aws-cdk-lib';
import { IStateMachine } from 'aws-cdk-lib/aws-stepfunctions';
import { Construct } from 'constructs';
export interface LambdalessProviderProps {
}
export declare class LambdalessProvider extends Construct {
    private readonly subscription;
    readonly stateMachine: cdk.aws_stepfunctions.StateMachine;
    constructor(scope: Construct, id: string, _props: LambdalessProviderProps);
    get serviceToken(): string;
    private createStateMachine;
}
/**
 * Properties to provide a Lambdaless custom resource
 */
export interface LambdalessCustomResourceProps {
    readonly workflow: IStateMachine;
    /**
     * The maximum time that can elapse before a custom resource operation times out.
     *
     * The value must be between 1 second and 3600 seconds.
     *
     * Maps to [ServiceTimeout](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cloudformation-customresource.html#cfn-cloudformation-customresource-servicetimeout) property for the `AWS::CloudFormation::CustomResource` resource
     *
     * A token can be specified for this property, but it must be specified with `Duration.seconds()`.
     *
     * @example
     * const stack = new Stack();
     * const durToken = new CfnParameter(stack, 'MyParameter', {
     *   type: 'Number',
     *   default: 60,
     * });
     * new CustomResource(stack, 'MyCustomResource', {
     *   serviceToken: 'MyServiceToken',
     *   serviceTimeout: Duration.seconds(durToken.valueAsNumber),
     * });
     *
     * @default Duration.seconds(3600)
     */
    readonly serviceTimeout?: cdk.Duration;
    /**
     * Properties to pass to the Lambda
     *
     * Values in this `properties` dictionary can possibly overwrite other values in `CustomResourceProps`
     * E.g. `ServiceToken` and `ServiceTimeout`
     * It is recommended to avoid using same keys that exist in `CustomResourceProps`
     *
     * @default - No properties.
     */
    readonly properties?: {
        [key: string]: any;
    };
    /**
     * For custom resources, you can specify AWS::CloudFormation::CustomResource
     * (the default) as the resource type, or you can specify your own resource
     * type name. For example, you can use "Custom::MyCustomResourceTypeName".
     *
     * Custom resource type names must begin with "Custom::" and can include
     * alphanumeric characters and the following characters: _@-. You can specify
     * a custom resource type name up to a maximum length of 60 characters. You
     * cannot change the type during an update.
     *
     * Using your own resource type names helps you quickly differentiate the
     * types of custom resources in your stack. For example, if you had two custom
     * resources that conduct two different ping tests, you could name their type
     * as Custom::PingTester to make them easily identifiable as ping testers
     * (instead of using AWS::CloudFormation::CustomResource).
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cfn-customresource.html#aws-cfn-resource-type-name
     *
     * @default - AWS::CloudFormation::CustomResource
     */
    readonly resourceType?: string;
    /**
     * The policy to apply when this resource is removed from the application.
     *
     * @default cdk.RemovalPolicy.Destroy
     */
    readonly removalPolicy?: cdk.RemovalPolicy;
    /**
     * Convert all property keys to pascal case.
     *
     * @default false
     */
    readonly pascalCaseProperties?: boolean;
}
export declare class LambdalessCustomResource extends Construct {
    private readonly resource;
    readonly ref: string;
    constructor(scope: Construct, id: string, props: LambdalessCustomResourceProps);
    /**
     * Returns the value of an attribute of the custom resource of an arbitrary
     * type. Attributes are returned from the custom resource provider through the
     * `Data` map where the key is the attribute name.
     *
     * @param attributeName the name of the attribute
     * @returns a token for `Fn::GetAtt`. Use `Token.asXxx` to encode the returned `Reference` as a specific type or
     * use the convenience `getAttString` for string attributes.
     */
    getAtt(attributeName: string): cdk.Reference;
    /**
     * Returns the value of an attribute of the custom resource of type string.
     * Attributes are returned from the custom resource provider through the
     * `Data` map where the key is the attribute name.
     *
     * @param attributeName the name of the attribute
     * @returns a token for `Fn::GetAtt` encoded as a string.
     */
    getAttString(attributeName: string): string;
}
